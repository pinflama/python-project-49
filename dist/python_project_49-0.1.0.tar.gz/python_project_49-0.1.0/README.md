### Install package

[![asciicast](https://asciinema.org/a/OqcyAI9QrbWw759KCtN69sdt8.svg)](https://asciinema.org/a/OqcyAI9QrbWw759KCtN69sdt8)

___

## Usage

### Demo

#### Brain Even

[![asciicast](https://asciinema.org/a/ftQWlXcGsh6ojTkrlAbngy74h.svg)](https://asciinema.org/a/ftQWlXcGsh6ojTkrlAbngy74h)


#### Brain Calc

[![asciicast](https://asciinema.org/a/pDN8gzRB66peFXYYk36Hg6Wqo.svg)](https://asciinema.org/a/pDN8gzRB66peFXYYk36Hg6Wqo)


### Hexlet tests and linter status:
[![Actions Status](https://github.com/pinflama/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/pinflama/python-project-49/actions)
